
function demo_experiment_02

%--------------------------------------------------------------------------
% OBJECT.
% This function runs the experiments for hyperinterpolation over a
% spherical polygon.
%
% Several hyperinterpolants are used on possibly noisy functions.
%
% It makes the following numerical experiments:
% a) Fixed noise and several well-chosen lambda parameters (where useful).
%
% At the end of the code it gives results for some hyperinterpolants, as
% table.
%--------------------------------------------------------------------------
% EXAMPLE:
% 
% % SETTINGS:
%
% % LV=10;
% % kV=20;
% % noiseV=[0.025 0.025; 0.05 0.05; 0.1 0.1; 0.3 0.3];
% % domain_parm=3;
% % do_compression=1;
% % funct_example=4;
%
% >> demo_experiment_02
% 
%  	 RELATIVE DATA RATIO: av.min: 1.30424e-04 av.max: 8.48158e-02
%  	 RELATIVE DATA RATIO: av.min: 7.47416e-05 av.max: 1.70184e-01
%  	 RELATIVE DATA RATIO: av.min: 2.59084e-04 av.max: 3.25124e-01
%  	 RELATIVE DATA RATIO: av.min: 1.11765e-03 av.max: 1.03770e+00
%  
%   HypType                           tablemat                    
%   ____________    ________________________________________________
% 
%   tikhonov        0.0081338      0.01555     0.032181     0.097921
%   filtered        0.0070817      0.01359      0.02869     0.086475
%   lasso            0.013921     0.016249     0.021415     0.037943
%   hybrid           0.013921     0.016245     0.021287     0.035772
%   hard            0.0091517     0.013047     0.026297     0.076976
%   hyperint.       0.0080254      0.01553     0.032225     0.099021
%   filt. spars.          121          121          121          121
%   hyb.spars.             19           19           19           19
%   lasso spars.           19           19           19           19
% 
% 
% ............ SOME COMMENTS ............ 
%  
%  	 IN THE TABLE WE DISPLAY THE AVERAGE L2 ERRORS
%  	 FOR RECONSTRUCTING NOISY FUNCTIONS ON THE DOMAIN,
%  	 USING SEVERAL LAMBDA PARAMETERS IN HYP. VARIANTS.
%  	 THE AVERAGE LAMBDA PARAMETERS ARE LISTED BELOW.
%  
% * DOMAIN: Australia as island (170 vertices, via polyshape)
% 
% * FUNCTION: exp((x.^6).*cos(y+2*z))
% 
% [1] IMPULSE NOISE PARM;: 2.50000e-02 GAUSSIAN NOISE PARM.: 2.50000e-02
% [2] IMPULSE NOISE PARM;: 5.00000e-02 GAUSSIAN NOISE PARM.: 5.00000e-02
% [3] IMPULSE NOISE PARM;: 1.00000e-01 GAUSSIAN NOISE PARM.: 1.00000e-01
% [4] IMPULSE NOISE PARM;: 3.00000e-01 GAUSSIAN NOISE PARM.: 3.00000e-01
%
% * COMPRESSED RULE AT DEG:  10
% * REF. RULE DEG:  30
% * CUB. PTS HYP:    441
% * CUB. PTS REF: 362646
% 
% * Lambda interval (for hyp. variants): [1.19e-02,1.58e-02] 
% 
% >> 
%--------------------------------------------------------------------------
% Dates:
% Written on September 29, 2023: A. Sommariva.
% Modified on February 15, 2024: A. Sommariva.
%--------------------------------------------------------------------------
% Reference papers:
%
% "Numerical cubature and Hyperinterpolation over Spherical Polygons"
% Alvise Sommariva
%
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


clear;
warning off;

% ............................. SETTINGS ..................................

% LV is the hyperinterpolation degree: choose strictly larger than 1.
% In numerical experiments we used LV=10.
LV=10;

% a) PART 1: fixed noise
% index determining the lambda coeff. of some hyp.variants
kV=20;

% noise coefficients: 
% the component noiseV(k,1) is the impulse noise in the k-th battery while
% noiseV(k,2) is the gaussian  sigma in the k-th battery while
noiseV=[0.025 0.025; 0.05 0.05; 0.1 0.1; 0.3 0.3];

% d) DOMAIN PARMS.
% 1. Polygonal cardioid at North-Pole,
% 2. Australia coarse.
% 3: Australia finer (no Tasmania).

domain_parm=3;
do_compression=1;

do_plot=1;

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. specific functions.
funct_example=4;

% ........................ main code below ................................



% .................... FIRST STAGE OF EXPERIMENTS   .......................

[vertices,domain_str]=define_domain(domain_parm);

AE2V=[]; betaV=[]; lambdaHIST=[];
XYZW=[]; XYZWR=[];

AE2V=[]; betaV=[];

for kk=1:size(noiseV,1)
    a2=noiseV(kk,1);
    sigma2=noiseV(kk,2);
    [AEinf,AE2,beta,lambdaV,lambdaLV,XYZW,XYZWR,JzMV,HzMV,...
    Wg_norm2,NR,pert_ratio]=make_experiments(kV,a2,...
        sigma2,vertices,XYZW,XYZWR,LV,do_compression,funct_example);
    AE2V=[AE2V AE2]; betaV=[betaV beta];
end




AE2T=AE2V(1,:); BETAT=betaV(1,:); % tikhonov data storage
AE2F=AE2V(2,:); BETAF=betaV(2,:); % filtered hyp. data storage
AE2L=AE2V(3,:); BETAL=betaV(3,:); % lasso hyp. data storage
AE2H=AE2V(4,:); BETAH=betaV(4,:); % Hybrid hyp. data storage
AE2HA=AE2V(5,:); BETAHA=betaV(5,:); % Hard hyp. data storage
AE20=AE2V(6,:); BETA0=betaV(6,:); % Hyp. data storage


% Making Matlab tables
AE2V1=AE2V; betaV1=betaV; BETAH1=BETAH; BETAL1=BETAL;

fprintf('\n \n')
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'filt. spars.';'hyb.spars.'; 'lasso spars.'});

tablemat=[AE2V1; BETAF; BETAH1; BETAL1];
T = table(HypType,tablemat); disp(T);

fprintf('\n \t ............ SOME COMMENTS ............ ');

fprintf('\n \n \t IN THE TABLE WE DISPLAY THE AVERAGE L2 ERRORS');
fprintf('\n \t FOR RECONSTRUCTING NOISY FUNCTIONS ON THE DOMAIN,');
fprintf('\n \t USING SEVERAL LAMBDA PARAMETERS IN HYP. VARIANTS.');
fprintf('\n \t THE AVERAGE LAMBDA PARAMETERS ARE LISTED BELOW.');

fprintf('\n \n \t * DOMAIN: '); disp(domain_str);

[g,fstring]=define_function(funct_example,LV);
fprintf('\n \t * FUNCTION: '); disp(fstring);

for kk=1:size(noiseV,1)
    a2=noiseV(kk,1);
    sigma2=noiseV(kk,2);
    fprintf('\n \t [%1.0f] IMPULSE NOISE PARM;: %1.5e  GAUSSIAN NOISE PARM.: %1.5e',...
        kk,a2,sigma2);
end



if do_compression
    fprintf('\n \t * COMPRESSED RULE AT DEG: %3.0f',LV);
else
    fprintf('\n \t * FULL RULE AT DEG: %3.0f',LV);
end
fprintf('\n \t * REF. RULE DEG: %3.0f',NR);
fprintf('\n \t * CUB. PTS HYP: %6.0f',size(XYZW,1));
fprintf('\n \t * CUB. PTS REF: %6.0f',size(XYZWR,1));

fprintf('\n');

fprintf('\n \t * Lambda interval (for hyp. variants): [%1.2e,%1.2e] \n',...
min(lambdaLV),max(lambdaLV))



fprintf('\n \n')



% plot domain
if do_plot
    plot_s2('spherical-polygon',vertices,XYZW(:,1:3));
end

clear all;



