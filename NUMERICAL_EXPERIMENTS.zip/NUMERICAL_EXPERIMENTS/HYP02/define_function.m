

function [g,fstring]=define_function(funct_example,L)

switch funct_example

    case 1 % test exactness hyperinterpolation
        nexp=L;
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        [c0 c1 c2 c3]
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;
        fstring=['Random Polynomial (c0+c1*x+c2*y+c3*z)^ %4.0f',num2str(nexp)];

    case 2 % test exactness filt. hyperinterpolation
        nexp=max(floor(L/2)-1,0);
        c0=rand(1); c1=rand(1); c2=rand(1); c3=rand(1);
        g=@(x,y,z) (c0+c1*x+c2*y+c3*z).^nexp;
        fstring=['Random Polynomial (c0+c1*x+c2*y+c3*z)^ %4.0f',num2str(nexp)];

    case 3
        g=@(x,y,z) 1+exp(-1./((x+0.6325).^2+(y-0.6668).^2+(z+0.3908).^2));
        fstring='100+exp(-1./((x+0.6325).^2+(y-0.6668).^2+(z+0.3908).^2))';
    
    case 4
        g=@(x,y,z) exp((x.^6).*cos(y+2*z));
        fstring='exp((x.^6).*cos(y+2*z))';
    
    case 5 % Test function used in a reference paper (nodes on S2).
        delta2=0.4;

        P1=[-5.385570185050902e-01     7.457401266714497e-01    -3.922091295354535e-01];
        P2=[ -3.926781627634456e-01     7.332469473606912e-01    -5.551151003845533e-01];
        P3=[ -7.055766983110676e-01     4.395907721102658e-01    -5.558070491420137e-01];
        P4=[ -5.787679851841416e-01     7.675775881261381e-01    -2.754129000834024e-01];
        P5=[ -6.242042116759032e-01     5.856230681031230e-01    -5.171215758712346e-01];
        P6=[-7.602616296420855e-01     6.074845889518453e-01    -2.301406715032529e-01];


        phi_tilde=@(r) (((1-r).*(1-r > 0)).^6).*(35*r.^2+18*r+3);
        r1=@(x,y,z) ((x-P1(1)).^2+(x-P1(2)).^2+(z-P1(3)).^2)/delta2;
        r2=@(x,y,z) ((x-P2(1)).^2+(x-P2(2)).^2+(z-P2(3)).^2)/delta2;
        r3=@(x,y,z) ((x-P3(1)).^2+(x-P3(2)).^2+(z-P3(3)).^2)/delta2;
        r4=@(x,y,z) ((x-P4(1)).^2+(x-P4(2)).^2+(z-P4(3)).^2)/delta2;
        r5=@(x,y,z) ((x-P5(1)).^2+(x-P5(2)).^2+(z-P5(3)).^2)/delta2;
        r6=@(x,y,z) ((x-P6(1)).^2+(x-P6(2)).^2+(z-P6(3)).^2)/delta2;
        g=@(x,y,z) (1/3)*(phi_tilde(r1(x,y,z))+...
            phi_tilde(r2(x,y,z))+phi_tilde(r3(x,y,z))+...
            phi_tilde(r4(x,y,z))+phi_tilde(r5(x,y,z))+...
            phi_tilde(r6(x,y,z)));
        fstring='Linear combination of Wendland 6 functions (nodes in Aust.)';

    case 6

        g=@(x,y,z) ((x+0.6325).^2+(y-0.6668).^2+(z+0.3908).^2).^(5/2);
        fstring='((x+0.6325).^2+(y-0.6668).^2+(z+0.3908).^2).^(5/2)';



end





