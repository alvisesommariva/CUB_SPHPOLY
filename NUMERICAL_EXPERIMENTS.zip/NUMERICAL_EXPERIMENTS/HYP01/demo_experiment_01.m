
function demo_experiment_01

%--------------------------------------------------------------------------
% OBJECT.
% This function runs the experiments for hyperinterpolation over a
% spherical polygon.
%
% Several hyperinterpolants are used on possibly noisy functions.
%
% It makes the following numerical experiments:
% a) Fixed noise and several well-chosen lambda parameters (where useful).

% At the end of the code it gives results for some hyperinterpolants, as
% table.
% -------------------------------------------------------------------------
% Dates:
% Written on September 29, 2023: A. Sommariva.
% Modified on February 15, 2024: A. Sommariva.
%--------------------------------------------------------------------------
% Reference papers:
%
% "Numerical cubature and Hyperinterpolation over Spherical Polygons"
% Alvise Sommariva
%
% "Hybrid hyperinterpolation over general regions"
% Congpei An · Alvise Sommariva · Jia-Shu Ran
%--------------------------------------------------------------------------
% COPYRIGHT
%--------------------------------------------------------------------------
% Copyright (C) 2023-
%
% Authors:
% Alvise Sommariva
%
% This program is free software: you can redistribute it and/or modify
% it under the terms of the GNU General Public License as published by
% the Free Software Foundation, either version 3 of the License, or
% (at your option) any later version.
%
% This program is distributed in the hope that it will be useful,
% but WITHOUT ANY WARRANTY; without even the implied warranty of
% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
% GNU General Public License for more details.
%
% You should have received a copy of the GNU General Public License
% along with this program.  If not, see <https://www.gnu.org/licenses/>.
%--------------------------------------------------------------------------


clear;
warning off;

% ............................. SETTINGS ..................................

% LV is the hyperinterpolation degree: choose strictly larger than 1.
% In numerical experiments we used LV=10.
LV=10;

% a) PART 1: fixed noise
% index determining the lambda coeff. of some hyp.variants
kV=[20 30 40 50];

% noise coefficients
a1=0.25; sigma1=0.25;

% d) DOMAIN PARMS.
% 1. Polygonal cardioid at North-Pole,
% 2. Australia coarse.
% 3: Australia finer (no Tasmania).

domain_parm=2;
do_compression=1;

do_plot=1;

% * Function to approximate:
% 1. degree L poly., 2. degree floor(L/2)-1 poly. 3. specific functions.
funct_example=4;

% ........................ main code below ................................



% .................... FIRST STAGE OF EXPERIMENTS   .......................

[vertices,domain_str]=define_domain(domain_parm);

AE2V=[]; betaV=[]; lambdaHIST=[];
XYZW=[]; XYZWR=[];

for k=kV

    % Technical note: Here we reuse the cub. rules once they are computes.
    [AEinf,AE2,beta,lambdaV,lambdaLV,XYZW,XYZWR,~,~,~,NR]=make_experiments(...
        k,a1,sigma1,vertices,XYZW,XYZWR,LV,do_compression,funct_example);

    AE2V=[AE2V AE2]; betaV=[betaV beta]; lambdaHIST=[lambdaHIST lambdaV];

end


AE2T=AE2V(1,:); BETAT=betaV(1,:); % tikhonov data storage
AE2F=AE2V(2,:); BETAF=betaV(2,:); % filtered hyp. data storage
AE2L=AE2V(3,:); BETAL=betaV(3,:); % lasso hyp. data storage
AE2H=AE2V(4,:); BETAH=betaV(4,:); % Hybrid hyp. data storage
AE2HA=AE2V(5,:); BETAHA=betaV(5,:); % Hard hyp. data storage
AE20=AE2V(6,:); BETA0=betaV(6,:); % Hyp. data storage


% Making Matlab tables
AE2V1=AE2V; betaV1=betaV; BETAH1=BETAH; BETAL1=BETAL;

fprintf('\n \n')
HypType=categorical({'tikhonov'; 'filtered'; 'lasso'; 'hybrid'; 'hard'; ...
    'hyperint.'; 'filt. spars.';'hyb.spars.'; 'lasso spars.'});

tablemat=[AE2V1; BETAF; BETAH1; BETAL1];
T = table(HypType,tablemat); disp(T);

fprintf('\n \t ............ SOME COMMENTS ............ ');

fprintf('\n \n \t IN THE TABLE WE DISPLAY THE AVERAGE L2 ERRORS');
fprintf('\n \t FOR RECONSTRUCTING NOISY FUNCTIONS ON THE DOMAIN,');
fprintf('\n \t USING SEVERAL LAMBDA PARAMETERS IN HYP. VARIANTS.');
fprintf('\n \t THE AVERAGE LAMBDA PARAMETERS ARE LISTED BELOW.');

fprintf('\n \n \t * DOMAIN: '); disp(domain_str);

[g,fstring]=define_function(funct_example,LV);
fprintf('\n \t * FUNCTION: '); disp(fstring);
fprintf('\n \t * IMPULSE NOISE PARAMETER: %1.5e',a1);
fprintf('\n \t * GAUSSIAN NOISE PARAMET.: %1.5e',sigma1);

if do_compression
    fprintf('\n \t * COMPRESSED RULE AT DEG: %3.0f',LV);
else
    fprintf('\n \t * FULL RULE AT DEG: %3.0f',LV);
end
fprintf('\n \t * REF. RULE DEG: %3.0f',NR);
fprintf('\n \t * CUB. PTS HYP: %6.0f',size(XYZW,1));
fprintf('\n \t * CUB. PTS REF: %6.0f',size(XYZWR,1));

fprintf('\n');

fprintf('\n \t * Lambda interval (for hyp. variants): [%1.2e,%1.2e] \n',...
    min(min(lambdaHIST(kV,:))),max(max(lambdaHIST(kV,:))));

for k=1:length(kV)
    kVL=kV(k);
    fprintf('\n \t * Lambda column %1.0f (average, k: %5.0f): %1.4e AE2: %1.3e',...
        k,kVL,mean(lambdaHIST(kVL,:)),AE2V(4,k));
end

fprintf('\n \n')



% plot domain
if do_plot
    plot_s2('spherical-polygon',vertices,XYZW(:,1:3));
end

clear all;



