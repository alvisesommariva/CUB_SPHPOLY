
function demo_cub_sphpgon

%--------------------------------------------------------------------------
% Demo of cubature over spherical polygons.
% Compact version for understanding its usage.
%--------------------------------------------------------------------------
% Information:
% Authors: A. Sommariva and M. Vianello.
% Date: June 13, 2021.
% Last update: February 20, 2024
%--------------------------------------------------------------------------
%% Copyright (C) 2021-
%% Alvise Sommariva, Marco Vianello.
%%
%% This program is free software; you can redistribute it and/or modify
%% it under the terms of the GNU General Public License as published by
%% the Free Software Foundation; either version 2 of the License, or
%% (at your option) any later version.
%%
%% This program is distributed in the hope that it will be useful,
%% but WITHOUT ANY WARRANTY; without even the implied warranty of
%% MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%% GNU General Public License for more details.
%%
%% You should have received a copy of the GNU General Public License
%% along with this program; if not, write to the Free Software
%% Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307 USA
%%
%% Authors:
%% Alvise Sommariva, Marco Vianello.
%--------------------------------------------------------------------------




% .................. Numerical code starts here ...........................

% Define spherical domain (cartesian coordinates)
vertices=[1 0 0; 0 1 0; 0 0 1; 0.5 0.5 sqrt(2)/2];

% Degree of precision:
n=10;

% 1. Compute full rule
XWF=cub_sphpgon(n,vertices); 

% 2. Caratheodory-Tchakaloff compression
[nodes,w,momerr,dbox]=dCATCHsph(n,XWF(:,1:3),XWF(:,4)); 
XWC=[nodes w];

% 3. Evaluate integrals of a function.
f=@(x,y,z) cos(2*(0.1*x+0.2*y+z));

% 3a. Full rule
fnodesF=feval(f,XWF(:,1),XWF(:,2),XWF(:,3));
wF=XWF(:,4);
IF=wF'*fnodesF;

% 3b. Compressed rule
fnodes=feval(f,XWC(:,1),XWC(:,2),XWC(:,3));
wC=XWC(:,4);
IC=wC'*fnodes;

% 3c. Adaptive rule
tol=10^(-9);
[IR,Ierr]=adaptive_cub_sphpgon(vertices,f,tol);

% 4. Comparison
REF=abs(IR-IF)/abs(IR); % Relative Error Full rule
REC=abs(IR-IC)/abs(IR); % Relative Error Compressed rule

fprintf('\n \n \t Algebraic Degree of Precision: %3.0f', n);

fprintf('\n \n \t Relative Error Full Rule: %1.3e', REF);
fprintf('\n \t Relative Error Comp Rule: %1.3e', REC);

fprintf('\n \n \t Nodes Full Rule: %8.0f', size(XWF(:,1),1));
fprintf('\n \t Nodes Comp Rule: %8.0f', size(XWC(:,1),1));

fprintf('\n \n');

plot_s2('',[],XWF(:,1:3),XWC(:,1:3))




