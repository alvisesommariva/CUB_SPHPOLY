function [nodes,w,momerr,dbox] = dCATCHsph(deg,X,u,LHDM_options,verbose)

%--------------------------------------------------------------------------
% Object:
% This routine implements the Caratheodory-Tchakaloff d-variate discrete
% measure compression over subdomains of the sphere.
%
% Examples of its application are probability measures (designs) or
% quadrature formulas.
% Moments are invariant (close to machine precision) up to degree "deg"
% and adapt to the (numerical) dimension of the polynomial space on the
% point set X.
% The routine works satisfactorily for low/moderate degrees, depending on 
% the dimension.
%
%                     ........ Important note ........ 
% The routine "dCATCHsph" is a variant of "dCATCH" for the sphere.
% Differently from the classical one it uses "dORTHVANDsph" instead of 
% "dORTHVAND"."
%--------------------------------------------------------------------------
% Input:
% deg: polynomial exactness degree;
% X: d-column array of point coordinates;
% * u: 1-column array of nonnegative weights, or nonnegative scalar in
%    case of equal weights;
% * LHDM_options: structure containing the values of optimization 
%       parameters (see "LHDM.m" for details); 
% * verbose: 0: no information from routine;
%            1: relevant information from routine;
%
% Note: the variables with an asterisk "*" are not mandatory and can be 
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output:
% nodes: d-column array of extracted mass points coordinates; the variable
%    "nodes" has rows that are also rows of "X", i.e. nodes represent a 
%    subset of "X";
% w: 1-column array of corresponding new positive weights;
% momerr: moment reconstruction error;
% * dbox: variable that defines a hyperrectangle with 
%    sides parallel to the axis, containing the domain (or pointset X in 
%    the discrete case). 
%    It is a matrix with dimension "2 x d", where "d" is the dimension of
%    the space in which it is embedded the domain. 
%    For instance, for a 2-sphere, it is "d=3", for a 2 dimensional  
%    polygon it is "d=2".
%    As example, the set "[-1,1] x [0,1]" is described as 
%                          "dbox=[-1 0; 1 1]".
%--------------------------------------------------------------------------
% Data:
% Written on 26/07/2020 by M. Dessole, F. Marcuzzi, M. Vianello.
% Modified by:
% 29/10/2020: M. Vianello;
% 04/11/2020: A. Sommariva.
%--------------------------------------------------------------------------

% .........................  Function Body ................................

% ..... troubleshooting .....

if nargin < 5, verbose=[]; end
if nargin < 4, LHDM_options=[]; end
if nargin < 3, u=[]; end

if isempty(verbose), verbose=0; end
if isempty(LHDM_options)
    dim = size(X,2);
    LHDM_options = struct( 'k', ceil(nchoosek(2*deg+dim,dim)/(deg*dim)),...
        'init', false, 'thres', 0.2222, 'thres_w', 0.8);
end
if isempty(u), u=1; end


% ..... Main code below .....

% Vandermonde-like matrix of a u-orthogonal polynomial basis on X


[U,~,~,~,dbox]=dORTHVANDsph(deg,X,u,[],[],[]);

if verbose
    fprintf('Vandermonde matrix size = %d x %d \n', size(U,1), size(U,2));
end

if size(U,1)<=size(U,2)
    if verbose
        fprintf('Vandermonde matrix not underdetermined: no compression');
        fprintf('\n');
    end
    % no compression expected
    nodes=X;
    
    if isscalar(u), u=u*ones(size(Q,1),1); end % weights saved as scalar
    w=u;
    momerr = 0;
    
else
    
    % further orthogonalization to reduce the conditioning
    [Q,~]=qr(U,0);
    
    % new moments
    if isscalar(u), u=u*ones(size(Q,1),1); end % weights saved as scalar
    orthmom=Q'*u;
    [nodes, w, momerr, ~]= NNLS(X, u, U, Q, orthmom, LHDM_options, verbose);
    
end










function [nodes, w, momerr, e]= NNLS(X, u, U, Q, orthmom, options, verbose)

%--------------------------------------------------------------------------
% Object:
% Caratheodory-Tchakaloff points and weights via accelerated NNLS
%--------------------------------------------------------------------------

tic;
if  isfield(options,'lsqnonneg')
    if options.lsqnonneg
        if verbose
            fprintf('Matlab lsqnonneg \n');
        end
        [weights,~,~,~,output] = lsqnonneg(Q',orthmom);
        iter = output.iterations;
        cardP = [];
    else
        [weights,~,~,iter]=LHDM(Q',orthmom,options,verbose);
    end
else
    [weights,~,~,iter]=LHDM(Q',orthmom,options,verbose);
end
e = toc;

% indexes of nonvanishing weights and compression
ind=find(abs(weights)>0);
nodes=X(ind,:);
w=weights(ind);

% moment reconstruction error
momerr=norm(U(ind,:)'*w-U'*u);

% displaying results
if verbose
    fprintf('NNLS number of outer iterations = %d \n', iter);
    fprintf('NNLS elapsed time = %.6f s  \n', e);
    fprintf('initial design cardinality = %4.0f \n',size(X,1));
    fprintf('concentrated support cardinality = %4.0f \n',length(w));
    fprintf('compression ratio = %4.0f \n',size(X,1)/length(w));
    fprintf('moment reconstruction error = %4.2e \n \n',momerr);
end










function [U,jvec,Q,R,dbox] = dORTHVANDsph(deg,X,u,jvec,C,dbox)

%--------------------------------------------------------------------------
% Object:
% This routine computes a Vandermonde-like matrix for degree "deg" on a 
% d-dimensional point cloud "X" in an total-degree discrete orthogonal 
% polynomial basis w.r.t. the nonnegative weight array "u". 
%--------------------------------------------------------------------------
% Input:
% deg: total degree of the algebraic polynomial basis; 
% X: d-column array of point coordinates;
% * u: 1-column array of nonnegative weights, or nonnegative scalar in
%    case of equal weights;
% * jvec: vector of column indexes that selects a polynomial basis;  
% * C : Chebyshev-Vandermonde matrix on "jvec" basis
% * dbox: variable that defines a hyperrectangle with sides parallel to the
%    axis, containing the domain (or "X" in the discrete case). 
%    If "dbox" is not provided, it is the smaller "hyperrectangle", with 
%    sides parallel to the cartesian axes, containing the pointset "X".
%    It is a matrix with dimension "2 x d", where "d" is the dimension of
%    the space in which it is embedded the domain. 
%    For instance, for a 2-sphere, it is "d=3", for a 2 dimensional polygon 
%    it is "d=2".
%    As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
%
% Note: the variables with an asterisk "*" are not mandatory and can be 
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output:
% U: Vandermonde-like matrix in a "u"-orthogonal polynomial basis on "X"; 
% jvec: vector of column indexes, selects a polynomial basis;
% Q: orthogonal factor in the QR decomposition
%                  diag(sqrt(u))*C(:,jvec)=Q*R 
%    where "C=dCHEBVAND(n,X,dbox)" (if not assigned in inputs);
% R: triangular matrix of the QR decomposition
% dbox: it defines a hyperrectangle with sides parallel to the axis, 
%    containing the domain (or the pointset if "dbox" was not assigned as
%    input variable.
%--------------------------------------------------------------------------
% Dates:
%
% Written on 26/07/2020 by M. Dessole, F. Marcuzzi, M. Vianello.
% Last update on 01/01/2021 by A. Sommariva.
%--------------------------------------------------------------------------



% ........................... Function body ...............................



% ...... troubleshooting ......

if nargin < 6, dbox=[]; end
if nargin < 5, C=[]; end
if nargin < 4, jvec=[]; end
if nargin < 3, u=[]; end

if isempty(C), [C,dbox]=dCHEBVAND(deg,X,dbox); end
if isempty(jvec), N=(deg+1)^2; else, N=length(jvec); end
% if isempty(jvec), N=rank(C); else, N=length(jvec); end
if isempty(u), u=1; end

% fprintf('\n \t Deg: %3.0f Numerical rank: %4.0f Dim: %4.0f',...
%    deg,N,(deg+1)^2);


% ......................... main code below ...............................

% ...... computing Vandermonde matrix "U" ......

% scaling the matrix rows by the sqrt of the weights 
B = zeros(size(C));
for k=1:length(C(1,:))
    B(:,k)=C(:,k).*sqrt(u);
end

% polynomial basis orthogonalization
if N<length(C(1,:)) % low rank (e.g. the domain is an algebraic surface)
    % fprintf('\n \t * Warning: Low rank: %4.0f deg: %4.0f ',N,deg);
    if isempty(jvec)
        [Q0,R0,pm]=qr(B,0); 
        jvec=pm(1:N);
        R=R0(1:N,1:N);
        Q=Q0(:,1:N);
    else
        [Q,R]=qr(B(:,jvec),0);
    end
else % full rank
    [Q,R]=qr(B,0);
    jvec=(1:N);
end

% evaluation of the orthogonal matrix
U=C(:,jvec)/R;





function [x,resnorm,exitflag, outeriter] = LHDM(C,d,options,verbose)

% LHDM solves underdetermined linear least squares with nonnegativity constraints
% using classic Lawson-Hanson algorithm accelerated by Deviation Maximization.

% INPUT
% C: underdetermined matrix
% d: column array of set points coordinates
% gefftol: G-efficiency threshold
% maxit: maximum number of iterations of the multiplicative algorithm
% options: structure containing the values of optimization parameters,
%    possible field are:
%    init  true if ULS initialization of Passive set is desired, false
%          otherwise
%    tol   tolerance on the projected residual, stop criterion
%    k     maximum number of indices to be added to the Passive set at each
%          iteration
%    thres threshold on the cosine of the angle between each pair of
%          columns cuncurrently added to the Passive set, value between
%          0 and 1

% OUTPUT
% x: sparse vector that minimizes NORM(d-C*x)
% resnorm: squared 2-norm of the residual: norm(d-C*X)^2
% exitflag: exit condition, possible value are:
%    1  LHDM converged with a solution X
%    0  Iteration count was exceeded, increasing the tolerance
%       (OPTIONS.Tol) may lead to a solution
% momerr: moment reconstruction error by the compressed measure

% 11/06/2020
% M. Dessole, F. Marcuzzi, M. Vianello

if nargin < 2
    error('MATLAB:LHDM:NotEnoughInputs',...
        getString(message('MATLAB:LHDM:NotEnoughInputs')));
end

if nargin < 3
    options=[];
end

if nargin < 4
    verbose=0;
end

[m,n] = size(C);

% Initialize vector of n zeros and Infs (to be used later)
nZeros = zeros(n,1);
wz = nZeros;

itmax = m*2;

% Initialize set of non-active columns to null
P = false(n,1);
cardP = 0;
% Initialize set of active columns to all and the initial point to zeros
Z = true(n,1);
x = nZeros;

% Check if options was created with optimoptions
if ~isempty(options)
    if ~isa(options,'struct')
        error('MATLAB:LDHM:ArgNotStruct',...
            getString(message('MATLAB:LHDM:commonMessages:ArgNotStruct')));
    end
    if isfield(options,'thres')
        thres = options.thres;
        if (thres <= eps)
            LHDMflag = 0;
        end
    else
        thres = 0.2222;
    end
    if isfield(options,'thres_w')
        thres_w = options.thres_w;
    else
        thres_w = 0.8;
    end
    if isfield(options,'k')
        k = options.k;
        if (k == 1)
            LHDMflag = 0;
        else
            LHDMflag = 1;
        end
    else
        k = ceil(m/20);
    end
    if isfield(options,'tol')
        tol = options.tol;
    else
        tol = 10*eps*norm(C,1)*length(C);
    end
    if isfield(options,'init')
        if options.init
            xtmp = C\d;
            Idx = find(xtmp>0);
            % Initialize set of non-active columns
            P(Idx) = true;
            % Initialize set of active columns
            Z(Idx) = false;
            % Initialize starting point
            x(P) = C(:,P)\d;
            tmp = find(x<0);
            if(size(tmp,1)>0)
                x(tmp) = 0;
                P(tmp) = false;
                Z(tmp) = true;
            end
            if verbose
                fprintf('LHDM(%d) with ULS inizialization\n', k);
            end
            cardP = sum(P);
        else
            if verbose
                fprintf('LHDM(%d) \n', k);
            end
        end
    else
        if verbose
            fprintf('LHDM(%d) \n', k);
        end
    end
else
    thres   = 0.2222;
    thres_w = 0.8;
    k = ceil(m/20);
    tol = 10*eps*norm(C,1)*length(C);
    LHDMflag = 1;
    if verbose
        fprintf('LHDM(%d) \n', k);
    end
end


if LHDMflag
    Cnorm = zeros(size(C));
    for j=1:n
        Cnorm(:,j) = C(:,j)/norm(C(:,j));
    end
end


resid = d - C*x;
w = C'*resid;

% Set up iteration criterion
outeriter = 0;
totiter = 0;


tol=tol*10^(-3);

% Outer loop to put variables into set to hold positive coefficients
while (any(Z) && (any(w(Z) > tol) || any(x(P) < 0) ) && (totiter < itmax) )
    outeriter = outeriter + 1;
    totiter = totiter+1;
    % Create wz, a Lagrange multiplier vector of variables in the zero set.
    % wz must have the same size as w to preserve the correct indices, so
    % set multipliers to -Inf for variables outside of the zero set.
    wz(P) = -Inf;
    wz(Z) = w(Z);
    
    if ((outeriter <= 1) || (~LHDMflag))
        % in first iteration we drop DM to ensure w_T > 0
        [~,t] = max(wz);
    elseif LHDMflag && (removedP ~= addedP)
        t = DM(Cnorm, wz, k, thres, thres_w);
        if (length(t) + cardP > m)
            t = t(1:m-cardP);
        end
        
    else
        [~,t] = max(wz);
    end
    % number of indices added to P
    addedP = length(t);
    
    % Reset intermediate solution z
    z = zeros(size(x));
    % Move variable t from zero set to positive set
    P(t) = true;
    Z(t) = false;
    % Compute intermediate solution using only variables in positive set
    z(P) = C(:,P)\d;
    
    % inner loop to remove elements from the positive set which no longer belong
    iter = 0;
    removedP = 0;
    while (any(z(P) <= 0) && (totiter < itmax))
        totiter = totiter +1;
        iter = iter+1;
        % Find indices where intermediate solution z is approximately negative
        Q = (z <= 0) & P;
        % Choose new x subject to keeping new x nonnegative
        b = x(Q)./(x(Q) - z(Q));
        alpha = min(b);
        x = x + alpha*(z - x);
        % number of indices removed from P
        t = find(((abs(x) < tol) & P))';
        removedP = removedP + length(t);
        % Reset Z and P given intermediate values of x
        Z = ((abs(x) < tol) & P) | Z;
        P = ~Z;
        % Reset z
        z = nZeros;
        % Compute intermediate solution using only variables in positive set
        z(P) = C(:,P)\d;
    end
    % update cardinality of P
    cardP = cardP + addedP-removedP;
    x=z;
    
    resid = d - C*x;
    w = C'*resid;
    
end

if (outeriter < itmax)
    exitflag = 1;
else
    exitflag = 0;
end

resnorm = resid'*resid;



function [p] = DM(Cnorm, wz, k, thres,thres_w)
% Deviation Maximization

[wzI, I] = sort(wz, 'descend');
t = I(1);
p = t;
thres_wloc = thres_w*wzI(1);
C = find(wzI>thres_wloc);
n = size(C,1);
add = 1;
for i = 2:n
    c = C(i);
    if (max(abs(Cnorm(:,I(c))'*Cnorm(:,p))) < thres)
        p = [I(c) p];
        add = add+1;
    end
    if (add >= k)
        break;
    end
end









function [V,dbox] = dCHEBVAND(deg,X,dbox)

%--------------------------------------------------------------------------
% Object:
% This routine computes the Chebyshev-Vandermonde matrix for degree "deg"
% on a d-dimensional point cloud "X".
%
% The Chebyshev basis is the tensorial Chebyshev basis of total degree
% "deg", shifted on the hyperrectangle defined by "dbox".
%
% If "dbox" is not provided, the routine sets that variable to define the
% smaller "hyperrectangle" (box) with sides parallel to the cartesian
% axes and containing the pointset "X".
%--------------------------------------------------------------------------
% Input:
% deg: polynomial degree;
% X: d-column array of "m" points cloud (matrix "m x d");
% * dbox: variable that defines the smallest hyperectangle with sides
%     parallel to the axis, containing the domain.
%     If "dbox" is not provided, it defines the smaller "hyperrectangle",
%     with sides parallel to the cartesian axes, containing the pointset
%     "X".
%     It is a matrix with dimension "2 x d", where "d" is the dimension
%     of the space in which it is embedded the domain.
%     For instance, for a 2-sphere, it is "d=3", while for a 2 dimensional
%     polygon it is "d=2".
%     As example, the set "[-1,1] x [0,1]" is described as "[-1 0; 1 1]".
%
% Note: the variables with an asterisk "*" are not mandatory and can be
% also set as empty matrix.
%--------------------------------------------------------------------------
% Output:
% V: shifted Chebyshev-Vandermonde matrix for degree "deg" on the pointset
%    "X", relatively to "dbox".
% dbox: variable that defines the hyperrectangle with sides parallel to the
%     axis, containing the domain.
%--------------------------------------------------------------------------
% Data:
% The original routine has been written by M. Dessole, F. Marcuzzi and
% M. Vianello on 11/06/2020.
% It has been modified on:
% 22/10/2020 by A. Sommariva;
% 29/10/2020 by M. Vianello;
% 05/11/2020 by A. Sommariva.
%--------------------------------------------------------------------------



% ........................... Function body ...............................



% ...... troubleshooting ......

% box containing the cloud
if nargin < 3, dbox=[]; end
if isempty(dbox)
    a=min(X); b=max(X); dbox=[a;b];
else
    a=dbox(1,:); b=dbox(2,:);
end



% ..... main code below .....

% d-uples of indices with sum less or equal to "deg" graded lexicographical
% order
d=size(X,2);
N = nchoosek(deg+d,d); duples = zeros(N,d);
for i=2:N
    duples(i,:) = mono_next_grlex(d,duples(i-1,:));
end

% mapping the mesh in the hypercube "[-1,1]^d"
map = zeros(size(X));
for i=1:d
    map(:,i)=(2*X(:,i)-b(i)-a(i))/(b(i)-a(i));
end

% Chebyshev-Vandermonde matrix on the mesh
T=chebpolys(deg,map(:,1));
V=T(:,duples(:,1)+1);
for i=2:d
    T=chebpolys(deg,map(:,i));
    V=V.*T(:,duples(:,i)+1);
end










function T=chebpolys(deg,x)

%--------------------------------------------------------------------------
% Object:
% This routine computes the Chebyshev-Vandermonde matrix on the real line
% by recurrence.
%--------------------------------------------------------------------------
% Input:
% deg: maximum polynomial degree
% x: 1-column array of abscissas
%--------------------------------------------------------------------------
% Output:
% T: Chebyshev-Vandermonde matrix at x, T(i,j+1)=T_j(x_i), j=0,...,deg.
%--------------------------------------------------------------------------
% Authors:
% Alvise Sommariva and Marco Vianello
% University of Padova, December 15, 2017
%--------------------------------------------------------------------------

T=zeros(length(x),deg+1);
t0=ones(length(x),1); T(:,1)=t0;
t1=x; T(:,2)=t1;

for j=2:deg
    t2=2*x.*t1-t0;
    T(:,j+1)=t2;
    t0=t1;
    t1=t2;
end









function x = mono_next_grlex ( m, x )

%*****************************************************************************80
%
%% MONO_NEXT_GRLEX: grlex next monomial.
%
%  Discussion:
%
%    Example:
%
%    M = 3
%
%    #  X(1)  X(2)  X(3)  Degree
%      +------------------------
%    1 |  0     0     0        0
%      |
%    2 |  0     0     1        1
%    3 |  0     1     0        1
%    4 |  1     0     0        1
%      |
%    5 |  0     0     2        2
%    6 |  0     1     1        2
%    7 |  0     2     0        2
%    8 |  1     0     1        2
%    9 |  1     1     0        2
%   10 |  2     0     0        2
%      |
%   11 |  0     0     3        3
%   12 |  0     1     2        3
%   13 |  0     2     1        3
%   14 |  0     3     0        3
%   15 |  1     0     2        3
%   16 |  1     1     1        3
%   17 |  1     2     0        3
%   18 |  2     0     1        3
%   19 |  2     1     0        3
%   20 |  3     0     0        3
%
%    Thanks to Stefan Klus for pointing out a discrepancy in a previous
%    version of this code, 05 February 2015.
%
%  Licensing:
%
%    This code is distributed under the GNU LGPL license.
%
%  Modified:
%
%    05 February 2015
%
%  Author:
%
%    John Burkardt
%
%  Parameters:
%
%    Input, integer M, the spatial dimension.
%
%    Input, integer X(M), the current monomial.
%    The first item is X = [ 0, 0, ..., 0, 0 ].
%
%    Output, integer X(M), the next monomial.
%

%
%  Ensure that 1 <= M.
%
if ( m < 1 )
    fprintf ( 1, '\n' );
    fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
    fprintf ( 1, '  M < 1\n' );
    error ( 'MONO_NEXT_GRLEX - Fatal error!' );
end
%
%  Ensure that 0 <= XC(I).
%
for i = 1 : m
    if ( x(i) < 0 )
        fprintf ( 1, '\n' );
        fprintf ( 1, 'MONO_NEXT_GRLEX - Fatal error!' );
        fprintf ( 1, '  X(I) < 0\n' );
        error ( 'MONO_NEXT_GRLEX - Fatal error!' );
    end
end
%
%  Find I, the index of the rightmost nonzero entry of X.
%
i = 0;
for j = m : -1 : 1
    if ( 0 < x(j) )
        i = j;
        break
    end
end
%
%  set T = X(I)
%  set X(I) to zero,
%  increase X(I-1) by 1,
%  increment X(M) by T-1.
%
if ( i == 0 )
    x(m) = 1;
    return
elseif ( i == 1 )
    t = x(1) + 1;
    im1 = m;
elseif ( 1 < i )
    t = x(i);
    im1 = i - 1;
end

x(i) = 0;
x(im1) = x(im1) + 1;
x(m) = x(m) + t - 1;

























